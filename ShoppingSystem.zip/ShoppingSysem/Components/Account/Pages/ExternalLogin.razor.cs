using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.WebUtilities;
using ShoppingSysem.Data;

namespace ShoppingSysem.Components.Account.Pages
{
    public partial class ExternalLogin
    {
        public const string LoginCallbackAction = "LoginCallback";

        private string? message;
        private ExternalLoginInfo? externalLoginInfo;

        [CascadingParameter]
        private HttpContext HttpContext { get; set; } = default!;

        [SupplyParameterFromForm]
        private InputModel Input { get; set; } = default!;

        [SupplyParameterFromQuery]
        private string? RemoteError { get; set; }

        [SupplyParameterFromQuery]
        private string? ReturnUrl { get; set; }

        [SupplyParameterFromQuery]
        private string? Action { get; set; }

        private string? ProviderDisplayName => externalLoginInfo?.ProviderDisplayName;

        protected override async Task OnInitializedAsync()
        {
            Input ??= new();

            if (RemoteError is not null)
            {
                RedirectManager.RedirectToWithStatus("Account/Login", $"Error from external provider: {RemoteError}", HttpContext);
                return;
            }

            var info = await SignInManager.GetExternalLoginInfoAsync();
            if (info is null)
            {
                RedirectManager.RedirectToWithStatus("Account/Login", "Error loading external login information.", HttpContext);
                return;
            }

            externalLoginInfo = info;

            if (HttpMethods.IsGet(HttpContext.Request.Method))
            {
                if (Action == LoginCallbackAction)
                {
                    await OnLoginCallbackAsync();
                    return;
                }

                // We should only reach this page via the login callback, so redirect back to
                // the login page if we get here some other way.
                RedirectManager.RedirectTo("Account/Login");
            }
        }

        private async Task OnLoginCallbackAsync()
        {
            if (externalLoginInfo is null)
            {
                RedirectManager.RedirectToWithStatus("Account/Login", "Error loading external login information.", HttpContext);
                return;
            }

            // Sign in the user with this external login provider if the user already has a login.
            var result = await SignInManager.ExternalLoginSignInAsync(
                externalLoginInfo.LoginProvider,
                externalLoginInfo.ProviderKey,
                isPersistent: false,
                bypassTwoFactor: false);

            if (result.Succeeded)
            {
                Logger.LogInformation(
                    "{Name} logged in with {LoginProvider} provider.",
                    externalLoginInfo.Principal.Identity?.Name,
                    externalLoginInfo.LoginProvider);
                RedirectManager.RedirectTo(ReturnUrl);
                return;
            }
            else if (result.RequiresTwoFactor)
            {
                RedirectManager.RedirectTo(
                    "Account/LoginWith2fa",
                    new() { ["returnUrl"] = ReturnUrl, ["rememberMe"] = false });
                return;
            }
            else if (result.IsLockedOut)
            {
                RedirectManager.RedirectTo("Account/Lockout");
                return;
            }
            // If the user does not have an account, then ask the user to create an account.
            if (externalLoginInfo.Principal.HasClaim(c => c.Type == ClaimTypes.Email))
            {
                Input.Email = externalLoginInfo.Principal.FindFirstValue(ClaimTypes.Email) ?? "";
            }
        }

        private async Task OnValidSubmitAsync()
        {
            if (externalLoginInfo is null)
            {
                RedirectManager.RedirectToWithStatus("Account/Login", "Error loading external login information during confirmation.", HttpContext);
                return;
            }

            var emailStore = GetEmailStore();
            var user = CreateUser();

            await UserStore.SetUserNameAsync(user, Input.Email, CancellationToken.None);
            await emailStore.SetEmailAsync(user, Input.Email, CancellationToken.None);

            var result = await UserManager.CreateAsync(user);
            if (result.Succeeded)
            {
                // External registration only ever creates Customer accounts.
                result = await UserManager.AddToRoleAsync(user, AppRoles.Customer);
                if (result.Succeeded)
                    result = await UserManager.AddLoginAsync(user, externalLoginInfo);

                if (result.Succeeded)
                {
                    Logger.LogInformation("User created an account using {Name} provider.", externalLoginInfo.LoginProvider);

                    var userId = await UserManager.GetUserIdAsync(user);
                    var code = await UserManager.GenerateEmailConfirmationTokenAsync(user);
                    code = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(code));

                    var callbackUrl = NavigationManager.GetUriWithQueryParameters(
                        NavigationManager.ToAbsoluteUri("Account/ConfirmEmail").AbsoluteUri,
                        new Dictionary<string, object?> { ["userId"] = userId, ["code"] = code });
                    try
                    {
                        await EmailSender.SendConfirmationLinkAsync(user, Input.Email, HtmlEncoder.Default.Encode(callbackUrl));
                    }
                    catch (EmailDeliveryException)
                    {
                        message = "Error: Your account was created, but we could not send the confirmation email. " +
                                  "Please use \"Resend email confirmation\" later.";
                        return;
                    }

                    // If account confirmation is required, we need to show the link if we don't have a real email sender
                    if (UserManager.Options.SignIn.RequireConfirmedAccount)
                    {
                        RedirectManager.RedirectTo("Account/RegisterConfirmation", new() { ["email"] = Input.Email });
                    }
                    else
                    {
                        await SignInManager.SignInAsync(user, isPersistent: false, externalLoginInfo.LoginProvider);
                        RedirectManager.RedirectTo(ReturnUrl);
                    }
                }
                else
                {
                    // Never leave a half-created account (no role or no login) behind.
                    Logger.LogError(
                        "External registration failed for provider {Provider}: {Errors}",
                        externalLoginInfo.LoginProvider,
                        string.Join(",", result.Errors.Select(e => e.Code)));
                    await UserManager.DeleteAsync(user);
                    message = "Error: We could not complete your registration. Please try again.";
                }
            }
            else
            {
                // Same disclosure rule as password registration: do not reveal
                // whether the email address is already registered.
                message = result.Errors.Any(error =>
                    error.Code is "DuplicateUserName" or "DuplicateEmail")
                    ? "Error: Registration could not be completed. If you already have an account, sign in or reset your password."
                    : "Error: Registration could not be completed. Check the email address and try again.";
            }
        }

        private ApplicationUser CreateUser()
        {
            try
            {
                return Activator.CreateInstance<ApplicationUser>();
            }
            catch
            {
                throw new InvalidOperationException($"Can't create an instance of '{nameof(ApplicationUser)}'. " +
                    $"Ensure that '{nameof(ApplicationUser)}' is not an abstract class and has a parameterless constructor");
            }
        }

        private IUserEmailStore<ApplicationUser> GetEmailStore()
        {
            if (!UserManager.SupportsUserEmail)
            {
                throw new NotSupportedException("The default UI requires a user store with email support.");
            }
            return (IUserEmailStore<ApplicationUser>)UserStore;
        }

        private sealed class InputModel
        {
            [Required]
            [EmailAddress]
            public string Email { get; set; } = "";
        }
    }
}
